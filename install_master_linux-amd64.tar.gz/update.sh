#!/bin/bash

FILENAME=$(basename -- "$0")
SCRIPTPATH="$( cd "$(dirname "$0")" ; pwd -P )"
UPDATETYPE="update"
INSTALLOPT="-u"
RESUME_INSTALL=0
BINDIR=""
CHANNEL=""
DATADIRS=()
NOSTART=""
BINDIRSPEC="-p ${SCRIPTPATH}"
DATADIRSPEC=""

while [ "$1" != "" ]; do
    case "$1" in
        -i)
            UPDATETYPE="install"
            INSTALLOPT="-i"
            ;;
        -u)
            UPDATETYPE="update"
            INSTALLOPT="-u"
            ;;
        -m)
            UPDATETYPE="migrate"
            INSTALLOPT="-m"
            ;;
        -r)
            RESUME_INSTALL=1
            ;;
        -c)
            shift
            CHANNEL="$1"
            ;;
        -d)
            shift
            DATADIRS+=($1)
            DATADIRSPEC+="-d $1 "
            ;;
        -p)
            shift
            BINDIR="$1"
            BINDIRSPEC="-p $1"
            ;;
        -n)
            NOSTART="-n"
            ;;
        *)
            echo "Unknown option" "$1"
            exit 1
            ;;
    esac
    shift
done

# If this is an update, we'll validate that before doing anything else.
# If this is an install, we'll create it.
if [ ${RESUME_INSTALL} -eq 0 ]; then
    if [ "${BINDIR}" = "" ]; then
        BINDIR="${SCRIPTPATH}"
    fi
fi

# If -d not specified, default to ~/.algorand for dev and ~/.algorand-testnet for everything else
if [ "${#DATADIRS[@]}" -eq 0 ]; then
    if [ "${CHANNEL}" = "dev" ]; then
        DATADIRS+=("${HOME}/.algorand")
    else
        DATADIRS+=("${HOME}/.algorand-testnet")
    fi
fi

CURRENTVER=0

ROLLBACK=0
ROLLBACKBIN=0
ROLLBACKDATA=()
NEW_LEDGER=0
RESTART_NODE=0

function check_install_valid() {
    # Check for key files that indicate a valid install that can be updated
    if [ ! -f "${BINDIR}/algod" ]; then
        echo "Missing ${BINDIR}/algod"
        return 1
    fi
    return 0
}

function validate_channel_specified() {
    if [ "${CHANNEL}" = "" ]; then
        CHANNEL="$((${BINDIR}/algod -c) | head -n 1)"
        if [ "${CHANNEL}" = "" ]; then
            echo "Unable to determine release channel - please run again with -c <channel>"
            return 1
        fi
    fi
}

function determine_current_version() {
    CURRENTVER="$(( ${BINDIR}/algod -v || echo 0 ) | head -n 1)"
    echo Current Version = ${CURRENTVER}
}

function check_for_update() {
    determine_current_version
    LATEST="$(${SCRIPTPATH}/updater ver check -c ${CHANNEL})"
    if [ $? -ne 0 ]; then
        echo No remote updates found
        return 1
    fi

    echo Latest Version = ${LATEST}

    if [ ${CURRENTVER} -ge ${LATEST} ]; then
        echo No new version found
        return 1
    fi

    echo New version found
    return 0
}

TEMPDIR=""
TARFILE=""
UPDATESRCDIR=""

function download_update() {
    SPECIFIC_VERSION=$1
    TEMPDIR=$(mktemp -d 2>/dev/null || mktemp -d -t "tmp")
    trap "rm -rf ${TEMPDIR}" 0

    TARFILE=${TEMPDIR}/${LATEST}.tar.gz
    UPDATESRCDIR=${TEMPDIR}/a
    mkdir ${UPDATESRCDIR}

    ${SCRIPTPATH}/updater ver get -c ${CHANNEL} -o ${TARFILE} ${SPECIFIC_VERSION}

    if [ $? -ne 0 ]; then
        echo Error downloading update file
        exit 1
    fi
    echo Update Downloaded to ${TARFILE}
}

function check_and_download_update() {
    check_for_update
    if [ $? -ne 0 ]; then return 1; fi

    download_update
}

function download_update_for_current_version() {
    determine_current_version
    echo "Downloading update package for current version ${CURRENTVER}..."
    download_update "-v ${CURRENTVER}"
}

function expand_update() {
    echo Expanding update...

    tar -zxof ${TARFILE} -C ${UPDATESRCDIR}
    if [ $? -ne 0 ]; then return 1; fi

    validate_update
}

function validate_update() {
    echo Validating update...
    # We should consider including a version.info file
    # that we can compare against the expected version
    return 0
}

function shutdown_node() {
    echo Stopping node...
    if [ "$(pgrep -x algod)" != "" ]; then
        if [ -f ${BINDIR}/goal ]; then
            for DD in ${DATADIRS[@]}; do
                if [ -f ${DD}/algod.pid ]; then
                    echo Stopping node and waiting...
                    ${BINDIR}/goal node stop -d ${DD}
                    sleep 5
                else
                    echo "Node is running but not in ${DD} - not stopping"
                fi
            done
        fi
    else
        echo ... node not running
    fi
    RESTART_NODE=1
}

function backup_binaries() {
    echo Backing up current binary files...
    mkdir -p ${BINDIR}/backup
    tar -zcf ${BINDIR}/backup/bin-v${CURRENTVER}.tar.gz -C ${BINDIR} algod carpenter doberman goal update.sh updater updatekey.json >/dev/null 2>&1
}

function backup_data() {
    CURDATADIR=$1
    BACKUPDIR="${CURDATADIR}/backup"

    echo "Backing up current data files from ${CURDATADIR}..."
    mkdir -p ${BACKUPDIR}
    tar --exclude='*.log' --exclude='*.tar.gz' --exclude='backup' -zcf ${BACKUPDIR}/data-v${CURRENTVER}.tar.gz -C ${CURDATADIR} . >/dev/null 2>&1
}

function backup_current_version() {
    backup_binaries
    for DD in ${DATADIRS[@]}; do
        backup_data ${DD}
    done
}

function rollback_binaries() {
    echo "Rolling back binary files..."
    tar -zxof ${BINDIR}/backup/bin-v${CURRENTVER}.tar.gz -C ${BINDIR}
}

function rollback_data() {
    CURDATADIR=$1
    BACKUPDIR="${CURDATADIR}/backup"

    echo "Rolling back data files in ${CURDATADIR}..."
    rm ${CURDATADIR}/wallet-genesis.id
    tar -zxof ${BACKUPDIR}/data-v${CURRENTVER}.tar.gz -C ${CURDATADIR}
}

function install_new_binaries() {
    if [ ! -d ${UPDATESRCDIR}/bin ]; then
        return 0
    else
        echo Installing new binary files...
        ROLLBACKBIN=1
        rm -rf ${BINDIR}/new
        mkdir ${BINDIR}/new
        cp ${UPDATESRCDIR}/bin/* ${BINDIR}/new
        mv ${BINDIR}/new/* ${BINDIR}
        rm -rf ${BINDIR}/new
    fi
}

function reset_wallets_for_new_ledger() {
    CURDATADIR=$1

    echo "New Ledger - restoring genesis wallets in ${CURDATADIR}"
    pushd ${CURDATADIR} >/dev/null
    for file in *.genesis; do
        if [ -e "${file}" ]; then
            mkdir -p "${NEW_VER}"
            wallet="$(basename "${file}" .genesis).wallet"
            cp "${file}" "${NEW_VER}/${wallet}"
            echo 'Installed genesis wallet: ' "${wallet}"
        fi
    done
    popd >/dev/null
}

function install_new_data() {
    if [ ! -d ${UPDATESRCDIR}/data ]; then
        return 0
    else
        CURDATADIR=$1
        echo "Installing new data files into ${CURDATADIR}..."
        ROLLBACKDATA+=(${CURDATADIR})
        cp ${UPDATESRCDIR}/data/* ${CURDATADIR}
    fi
}

function check_for_new_ledger() {
    CURDATADIR=$1
    echo "Checking for new ledger in ${CURDATADIR}"
    NEW_VER=$(${UPDATESRCDIR}/bin/algod -d ${CURDATADIR} -g ${UPDATESRCDIR}/genesis/genesis.json -G)
    if [ $? -ne 0 ]; then
        echo "Cannot determine new genesis ID. Not updating. This may be a problem!"
        return 1
    fi
    EXISTING_VER="$(head -n 1 ${CURDATADIR}/wallet-genesis.id)"

    if [ "${NEW_VER}" != "${EXISTING_VER}" ]; then
        echo "New genesis ID, resetting wallets"
        NEW_LEDGER=1
        cp ${UPDATESRCDIR}/genesis/genesis.json ${CURDATADIR}
        echo ${NEW_VER} > ${CURDATADIR}/wallet-genesis.id
        reset_wallets_for_new_ledger ${CURDATADIR}
    fi
}

# Generate tar.gz with all log files, stored as logs.tar.gz in $BACKUPDIR
# and delete all logs if successful.
# Note for now we keep replacing the archive - we want to upload to S3
# eventually but for now we don't.
# Need to figure out how to uniquely identify them so we can identify their source.
function archive_logs() {
    CURDATADIR=$1
    BACKUPDIR="${CURDATADIR}/backup"

    pushd ${CURDATADIR} >/dev/null # Change to datadir so archive paths are relative to here
    tar -zcf logs.tar.gz *.log >/dev/null 2>&1
    Result=$?
    if [ ${Result} -eq 0 ]; then
        mkdir -p ${BACKUPDIR}
        mv logs.tar.gz ${BACKUPDIR}
        rm -f *.log
        echo Logs archived and deleted
    else
        rm -f logs.tar.gz
        echo "Failed to archive logs (or none to archive)"
    fi
    popd >/dev/null
    return ${Result}
}

function startup_node() {
    if [ "${NOSTART}" != "" ]; then
        echo Auto-start node disabled - not starting
        return
    fi

    CURDATADIR=$1
    echo Starting node in ${CURDATADIR}...

    check_install_valid
    if [ $? -ne 0 ]; then
        fail_and_exit "Installation does not appear to be valid"
    fi

    ${BINDIR}/goal node start -d ${CURDATADIR}
}

function startup_nodes() {
    for DD in ${DATADIRS[@]}; do
        startup_node ${DD}
    done
}

function rollback() {
    echo Rolling back from failed update...
    if [ ${ROLLBACKBIN} -ne 0 ]; then
        rollback_binaries
    fi
    for ROLLBACKDIR in ${ROLLBACKDATA[@]}; do
        rollback_data ${ROLLBACKDIR}
    done
}

function fail_and_exit() {
    echo "*** UPDATE FAILED: $1 ***"
    if [ ${ROLLBACK} -ne 0 ]; then
        ROLLBACK=0
        rollback
        check_install_valid
        if [ ${RESTART_NODE} -ne 0 ]; then
            startup_nodes
        fi
        exit 0
    fi
    exit 1
}

function apply_fixups() {
    echo "Applying migration fixups..."

    # Delete obsolete algorand binary - renamed to 'goal'
    rm ${BINDIR}/algorand >/dev/null 2>&1
}

#--------------------------------------------
# Main Update Driver

# Need to verify the bindir was specified (with -p)
# and that it's a valid directory.
# Unless it's an install
if [ ! -d "${BINDIR}" ]; then
    if [ "${UPDATETYPE}" = "install" ]; then
        mkdir -p ${BINDIR}
    else
        fail_and_exit "Missing or invalid binaries path specified '${BINDIR}'"
    fi
fi

if [ "${UPDATETYPE}" != "install" ]; then
    check_install_valid
    if [ $? -ne 0 ]; then
        echo "Unable to perform an update - installation does not appear valid"
        exit 1
    fi
fi

# If we're initiating an update/install, check for an update and if we have a new one,
# expand it and invoke the new update.sh script.
if [ ${RESUME_INSTALL} -eq 0 ]; then
    validate_channel_specified

    if [ "${UPDATETYPE}" = "migrate" ]; then
        download_update_for_current_version
    else
        check_and_download_update
    fi

    if [ $? -ne 0 ]; then
        # No update - stop here
        exit $?
    fi

    expand_update
    if [ $? -ne 0 ]; then
        fail_and_exit "Error expanding update"
    fi

    # Spawn the new update script and exit - this allows us to push update.sh changes that take effect immediately
    # Note that the SCRIPTPATH we're passing in should be our binaries directory, which is what we expect to be
    # passed as the last argument (if any)
    echo "Starting the new update script to complete the installation..."

    for DD in ${DATADIRS[@]}; do
        archive_logs ${DD}
    done
    exec "${UPDATESRCDIR}/bin/${FILENAME}" ${INSTALLOPT} -r -c ${CHANNEL} ${DATADIRSPEC} ${NOSTART} ${BINDIRSPEC}

    # If we're still here, exec failed.
    fail_and_exit "Error executing the new update script - unable to continue"
else
    # We're running the script from our expanded update, which is located in the last script's ${TEMPDIR}/a/bin
    # We need to define our TEMPDIR and UPDATESRCDIR to match those values; we do so by making them relative
    # to where our resuming script lives.
    TEMPDIR=${SCRIPTPATH}/../..
    UPDATESRCDIR=${SCRIPTPATH}/..
    echo "... Resuming installation from the latest update script"

    determine_current_version
fi

# Shutdown node before backing up so data is consistent and files aren't locked / in-use.
shutdown_node

backup_current_version

for DD in ${DATADIRS[@]}; do
    archive_logs ${DD}
done
# We don't care about return code - doesn't matter if we failed to archive

ROLLBACK=1

install_new_binaries
if [ $? -ne 0 ]; then
    fail_and_exit "Error installing new files"
fi

for DD in ${DATADIRS[@]}; do
    install_new_data ${DD}
    if [ $? -ne 0 ]; then
        fail_and_exit "Error installing data files into ${DD}"
    fi
done

for DD in ${DATADIRS[@]}; do
    check_for_new_ledger ${DD}
    if [ $? -ne 0 ]; then
        fail_and_exit "Error updating ledger in ${DD}"
    fi
done

apply_fixups

if [ "${NOSTART}" != "" ]; then
    echo "Install complete - restart node manually"
else
    startup_nodes
fi

exit 0
